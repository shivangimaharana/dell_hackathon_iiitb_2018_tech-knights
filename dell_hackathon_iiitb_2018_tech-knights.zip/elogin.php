<?php include('server_1.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>login </title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Login</h2>
  </div>
	 
  <form method="post" action="elogin.php" >
  
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>EBOM ID</label>
  		<input type="text" name="eid" >
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="epassword">
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
  	</div>
	<a href="dell.php">back</a><br><br>
  	
  </form>
</body>
</html>