<?php include('Update.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>mbom update</title>
   <link rel="stylesheet" type="text/css" href="style.css">
   <link rel="stylesheet" type="text/css" href="new.css">
   
   


</head>
<body>
  <div class="header">
  	<h2>modify existing mbom</h2>
	
  </div>
<div class="split left">
  <div class="centered">
  <form action="modify.php" method="post">
  	<?php include('errors.php'); ?>
	
	<div class="input-group">
  	  <label>Enter Attribute name</label>
  	  <input type="text" name="aid" value="<?php echo $aid; ?>">
  	</div>
  	
  	<div class="input-group">
  	  <label>Serial_no</label>
  	  <input type="text" name="Serial_no" value="<?php echo $Serial_no; ?>">
  	</div>
	<div class="input-group">
  	  <label>Enter attribute value</label>
  	  <input type="text" name="atid" value="<?php echo $atid; ?>">
  	</div>
	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Submit</button>
  	</div>
	<a href="choice.php">back</a><br><br>
	
  	
 </div>
</div>
<div class="split right">
  <div class="centered">
  
	
		<?php
$con=mysqli_connect('localhost', 'root', '', 'dell');
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con,"SELECT * FROM newebom");
echo '<div style="width:50%">';
echo "<table>
    <tr>
		<td>serial_no</td>
		<td>Company</td>
		<td>Product</td>
		<td>TypeName</td>
		<td>Inches</td>
		<td>ScreenResolution</td>
		<td>Cpu</td>
		<td>Ram</td>
		<td>Memory</td>
		<td>Gpu</td>
		<td>OpSys</td>
		<td>Weight</td>
		<td>Price_euros</td>
		
	</tr>";
	


while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo"<td>".$row['serial_no']."</td>";
echo"<td>".$row['Company']."</td>";
echo"<td>".$row['Product']."</td>";
echo"<td>".$row['TypeName']."</td>";
echo"<td>".$row	['Inches']."</td>";
echo"<td>".$row['ScreenResolution']."</td>";
echo"<td>".$row	['Cpu']."</td>";
echo"<td>".$row	['Ram']."</td>";
echo"<td>".$row ['Memory']."</td>";
echo"<td>".$row	['Gpu']."</td>";
echo"<td>".$row ['OpSys']."</td>";
echo"<td>".$row	['Weight']."</td>";
echo"<td>".$row['Price_euros']."</td>";
echo "</tr>";
}
echo "</table>";
echo "</div>";
mysqli_close($con);
?>
	</tr>

  </div>
</div>

	
  </form>

</body>

</html>


