<?php

// initializing variables
$aid = "";
$Serial_no="";
$atid="";
$errors = array(); 
$k=1;
// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'dell');

// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $aid =  $_POST['aid'];
  $atid=$_POST['atid'];
  $Serial_no = $_POST['Serial_no'];
 
  

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($aid)) { array_push($errors, "Enter attribute name"); }
  
  if (empty($Serial_no)) { array_push($errors, "enter serial no "); }
  if (empty($atid)) { array_push($errors, "Enter attribute value"); }
  
  
  

  
  
  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	//$password = md5($password);//encrypt the password before saving in the database
	if($aid=='Company')
	{
		$sql=" UPDATE mbom SET  Company='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
  	else if($aid=='Product')
	{
		$sql=" UPDATE mbom SET  Product='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	else if($aid=='TypeName')
	{
		$sql=" UPDATE mbom SET  TypeName='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	else if($aid=='Inches')
	{
		$sql=" UPDATE mbom SET  Inches='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	else if($aid=='ScreenResolution')
	{
		$sql=" UPDATE mbom SET  ScreenResolution='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
  	else if($aid=='Ram')
	{
		$sql=" UPDATE mbom SET  Ram='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	else if($aid=='Cpu')
	{
		$sql=" UPDATE mbom SET  Cpu='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	else if($aid=='Memory')
	{
		$sql=" UPDATE mbom SET  Memory='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	
	else if($aid=='Gpu')
	{
		$sql=" UPDATE mbom SET  Gpu='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	else if($aid=='OpSys')
	{
		$sql=" UPDATE mbom SET  OpSys='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	if($aid=='Weight')
	{
		$sql=" UPDATE mbom SET  Weight='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
  	else if($aid=='Price_euros')
	{
		$sql=" UPDATE mbom SET  Price_euros='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	else if($aid=='silicone_keyboard_guard')
	{
		$sql=" UPDATE mbom SET  silicone_keyboard_guard='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	else if($aid=='laptop_bag')
	{
		$sql=" UPDATE mbom SET  laptop_bag='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
  	else if($aid=='charger_provided')
	{
		$sql=" UPDATE mbom SET  charger_provided='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	else if($aid=='user_manual')
	{
		$sql=" UPDATE mbom SET  user_manual='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	else if($aid=='qty')
	{
		$sql=" UPDATE mbom SET  qty='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	else if($aid=='description')
	{
		$sql=" UPDATE mbom SET  description='$atid' WHERE serial_no = '$Serial_no' ";
		mysqli_query($db, $sql);
		$k=($k)-1;
	}
	else
	{	
		array_push($errors, "attribute name does not exist");
	}
	$query_2= "SELECT * FROM newebom";
	$results_2 = mysqli_query($db, $query_2);
	$num_rows_2= mysqli_num_rows($results_2);
	if(($Serial_no<1)&& ($Serial_no>$num_rows_2))
	{	
		array_push($errors, "Serial no does not exist");
	}
  	
  	header('location: modify.php');
  }
}
?>

