<?php
$db = mysqli_connect('localhost', 'root', '', 'dell');
$query="SELECT*FROM mbominfo";
$results = mysqli_query($db,$query);


?>
<html>
<head>
<title>Employee Data</title>
</head>
<body>

<table width="600" border="1" cellpadding="1" cellspacing="1">
<tr>
<?php
while ($row = mysqli_fetch_array($results)) {
    
    foreach($row as $field) {
        echo '<td>' . htmlspecialchars($field) . '</td>';
    }
   
}
?>
 </tr>
 

</body>
</html>