<!DOCTYPE html>
<html>
<head>
  <title>create new mbom</title>
   <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
   <div class="header">
  	<h2>create new mbom</h2>
  </div>
<form action="Choice_1.php" method="post">
<div class="input-group">	
<a href="modify_1.php">Modify ebom</a><br><br>
</div>
</form>


</body>
</html>