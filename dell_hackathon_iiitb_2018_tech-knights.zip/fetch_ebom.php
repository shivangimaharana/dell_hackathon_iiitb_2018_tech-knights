<?php

$db = mysqli_connect('localhost', 'root', '', 'dell');

$var=array();
$sql="SELECT * FROM newebom";
$result=mysqli_query($db,$sql);
while($row=mysqli_fetch_assoc($result)) {
$var[]=$row;
}

echo json_encode($var);
?>