<!DOCTYPE html>
<html>
<head>
  <title>dell user</title>
   <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
   <div class="header">
  	<h2>create new mbom</h2>
  </div>
<form action="dell.php" method="post">
<div class="input-group">	
<a href="login.php">for mbom user</a><br><br>
<a href="elogin.php">for ebom user</a><br><br>
</div>
</form>


</body>
</html>
