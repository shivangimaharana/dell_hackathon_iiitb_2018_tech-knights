<?php


// initializing variables
//$name= "";
//$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'dell');

if (isset($_POST['reg_user'])) {
	
	//$name =  $_POST['name'];
	//if (empty($name)) { array_push($errors, "enter table name"); }
	//print $name;
	
	
		
		
		
			 
			if (isset($_POST['silicone_keyboard_guard'])) {
				$sql="ALTER TABLE mbom ADD silicone_keyboard_guard TEXT";
				mysqli_query($db,$sql);
				$sql="INSERT INTO mbominfo (mbom_name)VALUES ('silicone_keyboard_guard')";
				mysqli_query($db,$sql);
			} 
			if (isset($_POST['laptop_bag'])) {
				$sql="ALTER TABLE mbom ADD laptop_bag TEXT";
				mysqli_query($db,$sql);
				$sql="INSERT INTO mbominfo (mbom_name)VALUES ('laptop_bag')";
				mysqli_query($db,$sql);
			}
			if (isset($_POST['charger_provided'])) {
				$sql="ALTER TABLE mbom ADD charger_provided TEXT";
				mysqli_query($db,$sql);
				$sql="INSERT INTO mbominfo (mbom_name)VALUES ('charger_provided')";
				mysqli_query($db,$sql);
			}
			if (isset($_POST['user_manual'])) {
				$sql="ALTER TABLE mbom ADD user_manual TEXT";
				mysqli_query($db,$sql);
				$sql="INSERT INTO mbominfo (mbom_name)VALUES ('user_manual')";
				mysqli_query($db,$sql);
			}
			if (isset($_POST['qty'])) {
				$sql="ALTER TABLE mbom ADD qty TEXT";
				mysqli_query($db,$sql);
				$sql="INSERT INTO mbominfo (mbom_name)VALUES ('qty')";
				mysqli_query($db,$sql);
			}
			$sql="ALTER TABLE mbom ADD description TEXT";
				mysqli_query($db,$sql);
			$sql="INSERT INTO mbominfo (mbom_name)VALUES ('description')";
				mysqli_query($db,$sql);
			header('location: choice.php');
		
}

?>

